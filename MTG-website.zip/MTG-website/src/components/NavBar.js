import React from 'react';

function NavBar() {
  return (
    <div className="navbar">
      <input type="text" placeholder="Search..." />
    </div>
  );
}

export default NavBar;
